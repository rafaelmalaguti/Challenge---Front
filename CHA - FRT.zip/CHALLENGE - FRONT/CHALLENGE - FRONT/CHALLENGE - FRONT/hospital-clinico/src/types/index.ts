export interface TeamMember {
  id: string;
  name: string;
  role: string;
  rm: string;
  image: string;
  linkedin?: string;
  github?: string;
}

export interface Specialty {
  id: string;
  title: string;
  description: string;
  image: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

export interface NavItem {
  id: string;
  label: string;
  href: string;
  isButton?: boolean;
}






