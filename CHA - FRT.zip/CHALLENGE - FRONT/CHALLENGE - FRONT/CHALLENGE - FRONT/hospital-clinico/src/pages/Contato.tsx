import React from 'react';
import ContactForm from '../components/ContactForm';

const Contato: React.FC = () => {
  return (
    <div className="pt-20">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="section-title">Entre em Contato</h1>
            <p className="section-subtitle">
              Estamos à disposição para melhor atendê-lo
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Informações de Contato */}
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-map-marker-alt"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-hospital-blue mb-2">Endereço</h3>
                  <p className="text-gray-600">
                    Av. Dr. Enéas de Carvalho Aguiar, 255<br />
                    05403-000<br />
                    São Paulo - Brasil
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-phone-alt"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-hospital-blue mb-2">Telefones</h3>
                  <p className="text-gray-600">(0xx11) 2661-0000</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-envelope"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-hospital-blue mb-2">Email</h3>
                  <p className="text-gray-600">contato@hospitalclinico.com.br</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-clock"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-hospital-blue mb-2">Horário de Funcionamento</h3>
                  <p className="text-gray-600">
                    Funcionamento 24 horas por dia, indo em busca do seu bem-estar
                  </p>
                </div>
              </div>
            </div>
            
            {/* Formulário de Contato */}
            <ContactForm />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contato;






