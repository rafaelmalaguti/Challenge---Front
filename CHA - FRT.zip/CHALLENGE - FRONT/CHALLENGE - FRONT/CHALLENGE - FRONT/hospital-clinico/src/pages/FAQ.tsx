import React from 'react';
import FAQComponent from '../components/FAQ';
import { faqs } from '../data/mockData';

const FAQPage: React.FC = () => {
  return (
    <div className="pt-20">
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="section-title">Perguntas Frequentes</h1>
            <p className="section-subtitle">
              Tire suas dúvidas sobre nossos serviços
            </p>
          </div>
          
          <FAQComponent faqs={faqs} />
        </div>
      </section>
    </div>
  );
};

export default FAQPage;






