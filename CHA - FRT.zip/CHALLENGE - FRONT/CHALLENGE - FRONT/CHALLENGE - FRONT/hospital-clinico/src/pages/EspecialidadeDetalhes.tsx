import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { specialties } from '../data/mockData';
import Button from '../components/Button';

const EspecialidadeDetalhes: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const especialidade = specialties.find(s => s.id === id);

  if (!especialidade) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Especialidade não encontrada</h1>
          <Button onClick={() => navigate('/especialidades')} variant="primary">
            Voltar para Especialidades
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Botão de voltar */}
            <Button 
              onClick={() => navigate('/especialidades')} 
              variant="secondary" 
              className="mb-8"
            >
              ← Voltar para Especialidades
            </Button>

            {/* Conteúdo da especialidade */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src={especialidade.image} 
                alt={especialidade.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-8">
                <h1 className="text-3xl font-bold text-hospital-blue mb-4">
                  {especialidade.title}
                </h1>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  {especialidade.description}
                </p>
                
                {/* Informações adicionais baseadas no ID */}
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h2 className="text-xl font-semibold text-hospital-blue mb-4">
                    Informações Detalhadas
                  </h2>
                  {id === '1' && (
                    <div>
                      <p className="mb-2"><strong>Horário de Atendimento:</strong> Segunda a Sexta, 8h às 18h</p>
                      <p className="mb-2"><strong>Médicos Especialistas:</strong> 3 cardiologistas certificados</p>
                      <p className="mb-2"><strong>Exames Disponíveis:</strong> Ecocardiograma, Teste Ergométrico, Holter</p>
                    </div>
                  )}
                  {id === '2' && (
                    <div>
                      <p className="mb-2"><strong>Horário de Atendimento:</strong> Segunda a Sexta, 7h às 19h</p>
                      <p className="mb-2"><strong>Médicos Especialistas:</strong> 2 ortopedistas especializados</p>
                      <p className="mb-2"><strong>Procedimentos:</strong> Cirurgias, Fisioterapia, Infiltrações</p>
                    </div>
                  )}
                  {id === '3' && (
                    <div>
                      <p className="mb-2"><strong>Horário de Atendimento:</strong> Segunda a Sábado, 8h às 17h</p>
                      <p className="mb-2"><strong>Médicos Especialistas:</strong> 4 pediatras certificados</p>
                      <p className="mb-2"><strong>Serviços:</strong> Consultas, Vacinas, Acompanhamento do Desenvolvimento</p>
                    </div>
                  )}
                </div>

                {/* Botões de ação */}
                <div className="flex flex-col sm:flex-row gap-4 mt-8">
                  <Button 
                    onClick={() => navigate('/contato')} 
                    variant="primary"
                    className="flex-1"
                  >
                    Agendar Consulta
                  </Button>
                  <Button 
                    onClick={() => navigate('/equipe')} 
                    variant="secondary"
                    className="flex-1"
                  >
                    Conhecer Equipe
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EspecialidadeDetalhes;
