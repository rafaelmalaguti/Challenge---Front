import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import { specialties } from '../data/mockData';

const Especialidades: React.FC = () => {
  const navigate = useNavigate();

  const handleSpecialtyClick = (id: string) => {
    navigate(`/especialidades/${id}`);
  };

  return (
    <div className="pt-20">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="section-title">Nossas Especialidades</h1>
            <p className="section-subtitle">
              Cuidado integral para todas as fases da vida
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {specialties.map((specialty) => (
              <Card key={specialty.id} hover={true}>
                <div 
                  onClick={() => handleSpecialtyClick(specialty.id)}
                  className="cursor-pointer"
                >
                  <img 
                    src={specialty.image} 
                    alt={specialty.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-hospital-blue mb-3">
                      {specialty.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed mb-4">
                      {specialty.description}
                    </p>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSpecialtyClick(specialty.id);
                      }}
                      className="text-hospital-orange font-semibold hover:text-hospital-blue transition-colors"
                    >
                      Ver Detalhes →
                    </button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Especialidades;






