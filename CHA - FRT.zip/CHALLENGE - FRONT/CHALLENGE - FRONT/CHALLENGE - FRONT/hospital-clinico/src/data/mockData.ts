import { TeamMember, Specialty, FAQ, NavItem } from '../types';

export const navigationItems: NavItem[] = [
  { id: 'home', label: 'Início', href: '/' },
  { id: 'specialties', label: 'Especialidades', href: '/especialidades' },
  { id: 'team', label: 'Equipe', href: '/equipe' },
  { id: 'faq', label: 'FAQ', href: '/faq' },
  { id: 'contact', label: 'Contato', href: '/contato' },
  { id: 'solution', label: 'Solução', href: '/solucao' },
  { id: 'appointment', label: 'Chat', href: '/contato', isButton: true },
];

export const teamMembers: TeamMember[] = [
  {
    id: '1',
    name: 'Rafael Malaguti',
    role: 'Líder',
    rm: '561830',
    image: '/images/rafael.jpg',
    linkedin: 'https://www.linkedin.com/in/rafael-malaguti-481730340/',
    github: 'https://github.com/rafaelmalaguti'
  },
  {
    id: '2',
    name: 'Natalia Cristina Souza',
    role: 'Vendedora',
    rm: '564099',
    image: '/images/natalia.jpg',
    linkedin: 'https://www.linkedin.com/in/natalia-cristina-de-souza-333b92169',
    github: 'https://github.com/natcsouza'
  },
  {
    id: '3',
    name: 'Lincoln Roncato',
    role: 'Desenvolvedor',
    rm: '565944',
    image: '/images/lincoln.jpg',
    linkedin: 'https://www.linkedin.com/in/lincoln-roncato-266233353',
    github: 'https://github.com/lincolnroncato'
  }
];

export const specialties: Specialty[] = [
  {
    id: '1',
    title: 'Cardiologia',
    description: 'Cuidados preventivos e tratamento para doenças do coração com tecnologia avançada.',
    image: 'https://medcentersauderio.com.br/images/Blog/Cardiologia.jpg'
  },
  {
    id: '2',
    title: 'Ortopedia',
    description: 'Tratamento para lesões e doenças do sistema musculoesquelético com técnicas modernas.',
    image: 'https://www.esalud.com/wp-content/uploads/2023/02/ortopedia.jpg'
  },
  {
    id: '3',
    title: 'Pediatria',
    description: 'Cuidados especializados para bebês, crianças e adolescentes em ambiente acolhedor.',
    image: 'https://centromedicoabc.com/wp-content/uploads/2022/12/pediatria.jpg'
  }
];

export const faqs: FAQ[] = [
  {
    id: '1',
    question: 'Quais convênios são aceitos?',
    answer: 'Aceitamos os principais planos de saúde do mercado, incluindo Amil, Bradesco Saúde, SulAmérica, Unimed e muitos outros. Para verificar a cobertura completa do seu convênio, entre em contato conosco (Site, aplicativo ou telefone).'
  },
  {
    id: '2',
    question: 'Como agendar uma consulta?',
    answer: 'Você pode agendar sua consulta de três formas: 1) Por telefone através do (0xx11) 2661-0000. 2) Pessoalmente em nossa recepção. 3) Através do nosso aplicativo ou site disponível para iOS e Android. Recomendamos agendar com antecedência, especialmente para especialistas mais demandados.'
  },
  {
    id: '3',
    question: 'Qual o horário de funcionamento?',
    answer: 'Nosso pronto-socorro funciona 24 horas por dia, 7 dias por semana. As consultas ambulatoriais ocorrem de segunda a sexta das 7h às 19h, e aos sábados das 7h às 13h. Alguns exames especiais possuem horários diferenciados que podem ser consultados em nossa central.'
  }
];

