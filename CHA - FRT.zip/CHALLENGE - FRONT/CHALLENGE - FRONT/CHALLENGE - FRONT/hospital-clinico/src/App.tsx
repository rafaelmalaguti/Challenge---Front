import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Especialidades from './pages/Especialidades';
import Equipe from './pages/Equipe';
import FAQ from './pages/FAQ';
import Contato from './pages/Contato';
import Solucao from './pages/Solucao';
import EspecialidadeDetalhes from './pages/EspecialidadeDetalhes';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow pt-16">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/especialidades" element={<Especialidades />} />
          <Route path="/especialidades/:id" element={<EspecialidadeDetalhes />} />
          <Route path="/equipe" element={<Equipe />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/contato" element={<Contato />} />
          <Route path="/solucao" element={<Solucao />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;

