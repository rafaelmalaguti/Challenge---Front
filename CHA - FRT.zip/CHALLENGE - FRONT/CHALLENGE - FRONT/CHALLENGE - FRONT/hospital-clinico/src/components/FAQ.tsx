import React, { useState } from 'react';
import { FAQ } from '../types';

interface FAQProps {
  faqs: FAQ[];
}

const FAQComponent: React.FC<FAQProps> = ({ faqs }) => {
  const [activeFAQ, setActiveFAQ] = useState<string | null>(null);

  const toggleFAQ = (id: string) => {
    setActiveFAQ(activeFAQ === id ? null : id);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {faqs.map((faq) => (
        <div key={faq.id} className="mb-4 rounded-lg overflow-hidden shadow-lg">
          <button
            onClick={() => toggleFAQ(faq.id)}
            className="w-full p-6 bg-white text-left font-semibold text-hospital-blue hover:bg-gray-50 transition-colors duration-300 flex justify-between items-center"
          >
            <span>{faq.question}</span>
            <i className={`fas fa-chevron-down transition-transform duration-300 ${
              activeFAQ === faq.id ? 'rotate-180' : ''
            }`}></i>
          </button>
          <div className={`overflow-hidden transition-all duration-300 ${
            activeFAQ === faq.id ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
          }`}>
            <div className="p-6 bg-gray-50">
              <p className="text-gray-600 leading-relaxed whitespace-pre-line">
                {faq.answer}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default FAQComponent;






