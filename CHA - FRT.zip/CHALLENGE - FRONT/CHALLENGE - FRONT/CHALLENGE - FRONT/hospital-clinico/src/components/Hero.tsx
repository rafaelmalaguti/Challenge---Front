import React, { useState, useEffect } from 'react';
import Button from './Button';

const Hero: React.FC = () => {
  const [displayedText, setDisplayedText] = useState('');
  const fullText = 'Cuidando da sua saúde com excelência';

  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setDisplayedText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 60);

    return () => clearInterval(timer);
  }, []);

  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 90, 106, 0.8), rgba(70, 128, 139, 0.8)), url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')`
      }}
    >
      <div className="container mx-auto px-4 text-center text-white">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
          {displayedText}
          <span className="animate-pulse">|</span>
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-90">
          Tecnologia de ponta, profissionais qualificados e atendimento humanizado para sua melhor experiência em saúde.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="#contato">
            <Button variant="primary" size="large" className="w-full sm:w-auto">
              <i className="fas fa-calendar-alt mr-2"></i>
              Marque sua consulta
            </Button>
          </a>
          <a href="#especialidades">
            <Button variant="secondary" size="large" className="w-full sm:w-auto">
              <i className="fas fa-search mr-2"></i>
              Conheça nossos serviços
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;

