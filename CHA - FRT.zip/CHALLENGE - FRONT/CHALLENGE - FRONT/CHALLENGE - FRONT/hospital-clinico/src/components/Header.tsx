import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { navigationItems } from '../data/mockData';
import Button from './Button';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => setIsMenuOpen((prev) => !prev);
  const closeMenu = () => setIsMenuOpen(false);
  const handleChatbotClick = () => {
    navigate('/contato');
  };

  return (
    <header className={`fixed top-0 w-full bg-white shadow-lg z-50 transition-all duration-300 ${
      isScrolled ? 'shadow-xl' : ''
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img 
              src="https://inradiando.com.br/wp-content/uploads/2019/10/NOVO-LOGO-HC-2022.png" 
              alt="Hospital Clínico" 
              className="h-12"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            <ul className="flex items-center space-x-6">
              {navigationItems.map((item) => (
                <li key={item.id}>
                  {item.isButton ? (
                    <Button onClick={handleChatbotClick} size="medium" variant="primary">
                      {item.label}
                    </Button>
                  ) : (
                    <Link
                      to={item.href.replace('#', '')}
                      className={`font-semibold text-hospital-blue hover:text-hospital-orange transition-colors duration-300 ${
                        location.pathname === item.href.replace('#', '') ? 'text-hospital-orange' : ''
                      }`}
                    >
                      {item.label}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
            {/* Keep only the Chat from navigationItems; remove duplicate button */}
          </nav>

          {/* Mobile Menu Button */}
          <button onClick={toggleMenu} className="lg:hidden text-hospital-blue text-2xl">
            <i className="fas fa-bars"></i>
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={`lg:hidden transition-all duration-300 ${
          isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        } overflow-hidden`}>
          <nav className="py-4">
            <ul className="space-y-4">
              {navigationItems.map((item) => (
                <li key={item.id}>
                  {item.isButton ? (
                    <Button
                      onClick={() => {
                        handleChatbotClick();
                        closeMenu();
                      }}
                      size="medium"
                      variant="primary"
                      className="w-full"
                    >
                      {item.label}
                    </Button>
                  ) : (
                    <a
                      href={item.href}
                      onClick={closeMenu}
                      className={`block font-semibold text-hospital-blue hover:text-hospital-orange transition-colors duration-300 ${
                        currentHash === item.href ? 'text-hospital-orange' : ''
                      }`}
                    >
                      {item.label}
                    </a>
                  )}
                </li>
              ))}
              {/* Chat already present via navigationItems; remove duplicate */}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;

